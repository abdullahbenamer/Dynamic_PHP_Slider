<?php

include('include.php');

?>
<!DOCTYPE html>
<html>
 <head>
 <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@200;300;400;500;700;800;900&display=swap" rel="stylesheet">
  <title>Dynamic Slider</title>
  <link rel="stylesheet" href="style.css">
  
 </head>
 <body style="font-family: 'Tajawal', sans-serif;">